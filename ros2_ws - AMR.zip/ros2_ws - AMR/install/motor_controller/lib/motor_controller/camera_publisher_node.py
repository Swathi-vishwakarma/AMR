#!/usr/bin/env python3

import cv2
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge


class CameraPublisher(Node):
    def __init__(self):
        super().__init__('camera_publisher')
        self.publisher = self.create_publisher(Image, '/camera/image_raw', 10)
        self.timer = self.create_timer(1.0 / 30, self.publish_image)  # Adjust the publishing frequency as needed
        self.bridge = CvBridge()
        self.camera = cv2.VideoCapture(0)  # Use 0 or the appropriate index for your camera

        if not self.camera.isOpened():
            self.get_logger().error("Failed to open the camera")
            exit()

    def publish_image(self):
        ret, frame = self.camera.read()

        if not ret:
            self.get_logger().error("Failed to capture the image")
            exit()

        image_msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
        self.publisher.publish(image_msg)

        # Print a message when an image is captured
        self.get_logger().info("Image captured")


def main(args=None):
    rclpy.init(args=args)

    camera_publisher = CameraPublisher()

    rclpy.spin(camera_publisher)

    camera_publisher.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

