#!/usr/bin/env python3

import time
import board
import busio
import adafruit_mpu6050
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu

class GyroscopeNode(Node):
    def __init__(self):
        super().__init__('gyroscope_node')
        self.publisher_ = self.create_publisher(Imu, 'gyroscope_data', 10)

        # Initialize MPU6050
        i2c = busio.I2C(board.SCL, board.SDA)
        self.mpu = adafruit_mpu6050.MPU6050(i2c)

    def publish_gyroscope_data(self):
        # Read gyroscope data
        gyro_x, gyro_y, gyro_z = self.mpu.gyro

        # Create Imu message
        imu_msg = Imu()
        imu_msg.angular_velocity.x = gyro_x
        imu_msg.angular_velocity.y = gyro_y
        imu_msg.angular_velocity.z = gyro_z

        # Publish the Imu message
        self.publisher_.publish(imu_msg)

def main(args=None):
    rclpy.init(args=args)
    gyroscope_node = GyroscopeNode()
    timer_period = 0.1  # seconds
    gyroscope_node.create_timer(timer_period, gyroscope_node.publish_gyroscope_data)
    rclpy.spin(gyroscope_node)
    gyroscope_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
