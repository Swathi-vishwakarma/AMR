function print_available_apps {

}

function check_available_app {

}