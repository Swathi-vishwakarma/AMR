from setuptools import setup

package_name = 'motor_controller'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('lib/' + package_name, ['motor_controller/motor_node.py']),
        ('lib/' + package_name, ['motor_controller/camera_publisher_node.py']),
        ('lib/' + package_name, ['motor_controller/teleop_node.py']),
        ('lib/' + package_name, ['motor_controller/gyro.py']),  # Add this line for the gyro.py script
        
    ],
    install_requires=[
        'setuptools',
        'rclpy',
        'geometry_msgs'
    ],
    zip_safe=True,
    maintainer='Swathi Vishwakarma',
    maintainer_email='ubuntu@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={ 
        'console_scripts': [
            'controll = motor_controller.controll:main' , 
            'motor_node = motor_controller.motor_node:main' ,
            'camera_publisher_node = motor_controller.camera_publisher_node:main',
            'gyro_node = motor_controller.gyro:main', 
        ],
    },
)
