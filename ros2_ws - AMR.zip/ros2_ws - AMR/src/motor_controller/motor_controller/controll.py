#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from std_srvs.srv import Empty

import numpy as np
import cv2
import cv_bridge

# Import the motor control code
from gpiozero import Motor, GPIOZeroError
from time import sleep

# Define the motor pins
motor1_pin1 = 17
motor1_pin2 = 18
motor2_pin1 = 27
motor2_pin2 = 22

# Initialize the motors
try:
    motor1 = Motor(forward=motor1_pin1, backward=motor1_pin2)
    motor2 = Motor(forward=motor2_pin1, backward=motor2_pin2)
except GPIOZeroError:
    print("Failed to initialize motors. Make sure the GPIO pins are correct.")

# Function to control the motors
def control_motors(motor1_speed, motor2_speed, duration):
    try:
        # Set the motor speeds
        motor1.forward(motor1_speed)
        motor2.forward(motor2_speed)
        
        # Print a message while running the motors
        print("Running motors...")
        
        # Wait for the specified duration
        sleep(duration)
        
        # Stop the motors
        motor1.stop()
        motor2.stop()
        
        # Print a message after stopping the motors
        print("Motors stopped.")
    except GPIOZeroError:
        print("Failed to control motors.")

# Create a bridge between ROS and OpenCV
bridge = cv_bridge.CvBridge()

# Create a class for the follower node
class FollowerNode(Node):
    def __init__(self):
        super().__init__('follower')
       # Create a subscriber for the cmd_vel topic
        self.subscription = self.create_subscription(
            Twist,
            'cmd_vel',
            self.cmd_vel_callback,
            10
        )
        self.subscription

        # Create a subscriber for the image messages
        self.subscription_ = self.create_subscription(
            Image,
            'camera/image_raw',
            self.image_callback,
            rclpy.qos.qos_profile_sensor_data)
        self.subscription_

        # Create services for starting and stopping the follower
        self.start_service_ = self.create_service(Empty, 'start_follower', self.start_follower_callback)
        self.stop_service_ = self.create_service(Empty, 'stop_follower', self.stop_follower_callback)

        # Set the initial values for global variables
        self.image_input = None
        self.error = 0
        self.just_seen_line = False
        self.just_seen_right_mark = False
        self.should_move = False
        self.right_mark_count = 0
        self.finalization_countdown = None

    def start_follower_callback(self, request, response):
        """
        Start the robot.
        In other words, allow it to move (again)
        """
        self.should_move = True
        self.right_mark_count = 0
        self.finalization_countdown = None

        # Check if subscribing to '/cmd_vel' topic
        if self.subscription_:
            print("Subscribed to '/cmd_vel' topic.")
        else:
            print("Not subscribed to '/cmd_vel' topic.")

        return response

    def stop_follower_callback(self, request, response):
        """
        Stop the robot
        """
        self.should_move = False
        self.finalization_countdown = None
        return response

    def image_callback(self, msg):
        """
        Function to be called whenever a new Image message arrives.
        Update the global variable 'image_input'
        """
        self.image_input = bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

    def timer_callback(self):
        """
        Function to be called when the timer ticks.
        According to an image 'image_input', determine.
        """
        pass

def main(args=None):
    rclpy.init(args=args)

    follower = FollowerNode()

    while rclpy.ok():
        rclpy.spin_once(follower)

    follower.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

